package com.application;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component("restClientEx")
public class RESTClientExample {
    @Autowired
    private RestTemplate restTemplate;

    public String getAllCities() {
        return restTemplate.getForObject("http://localhost:8083/cities", String.class);
    }
}
