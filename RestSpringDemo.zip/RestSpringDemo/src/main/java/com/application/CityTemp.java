package com.application;

public class CityTemp {

	private City city;

	public CityTemp(){
		
	}
	public CityTemp(City city) {
		super();
		this.city = city;
	}
	
	public City getCity() {
		return city;
	}
	
}
