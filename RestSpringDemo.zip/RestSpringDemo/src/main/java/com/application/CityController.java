package com.application;

import java.util.Collection;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class CityController {
	
	@RequestMapping(value = "/cities", method = RequestMethod.GET)
	public Collection<City> getCityNames() {
		return CitySource.getCities();
	}

	
	@RequestMapping(value= "/addcities/{id}", method = RequestMethod.PUT)
	public ResponseEntity<String> put(@PathVariable("id") String id, @RequestParam("name") String name, @RequestParam("date") String date){

		 City obj = new City();
		 obj.setId(id);
		 obj.setDate(date);
		 obj.setName(name);
		 new CitySource().addCity(obj);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	

	@RequestMapping(value= "/addcity", method = RequestMethod.POST)
	public ResponseEntity<String> putCity(@RequestBody City city){
		new CitySource().addCity(city);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@RequestMapping(value ="/deletecity/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteCity(@PathVariable("id") String id){
		
		new CitySource().deleteCity(id);
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	/* @RequestMapping(value = "/HaaSh/{instanceId}/{key}", method = RequestMethod.PUT)
    public ResponseEntity<String> put(@PathVariable("instanceId") String instanceId,
                                      @PathVariable("key") String key,
                                      @RequestBody String value) {
        service.put(instanceId, key, value);
        return new ResponseEntity<>("{}", HttpStatus.CREATED);*/
	
	
}
