package com.application;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class CitySource {

	 private static final Map<String, City> CITIES = new HashMap<>();	 
	 static{
		 City obj = new City();
		 obj.setId("1");
		 obj.setDate("Feb 6");
		 obj.setName("PUNE");
		 
		 CITIES.put(obj.getId(), obj);
		 
		 obj = new City();
		 obj.setId("2");
		 obj.setDate("Feb 7");
		 obj.setName("MUMBAI");

		 CITIES.put(obj.getId(), obj);
		 
		 obj = new City();
		 obj.setId("3");
		 obj.setDate("Feb 8");
		 obj.setName("GOA");
		 
		 CITIES.put(obj.getId(), obj);
	 }
	 
	 public static Collection<City> getCities(){
		 return CITIES.values();
	 }
	 
	 
	 public static City getCity(int key){
		 return CITIES.get(key);
	 }
	 
	 public void  addCity(City city){
		  CITIES.put(city.getId(), city);
	 }
	 
	 public void  deleteCity(String key){
		  CITIES.remove(key);
	 }
	 
}
